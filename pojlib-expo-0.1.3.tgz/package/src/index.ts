export { default } from './PojlibExpoModule';
export { default as PojlibExpoView } from './PojlibExpoView';
export * from './PojlibExpo.types';

import PojlibExpoModule, {
  AddPojlibProjectOptions,
  AddPojlibModrinthVersionOptions,
  CreatePojlibInstanceOptions,
  CreatePojlibMrpackInstanceOptions,
  ImportLocalPojlibProjectOptions,
  InstallDefaultPojlibInstanceOptions,
  PojlibModLoader,
  PojlibConfig,
} from './PojlibExpoModule';

export const POJLIB_MOD_LOADERS: PojlibModLoader[] = ['Fabric', 'NeoForge'];
export const DEFAULT_POJLIB_MOD_LOADER: PojlibModLoader = 'Fabric';
const FALLBACK_SUPPORTED_VERSIONS = ['1.21.4'];

export function getDefaultPojlibInstanceName(
  minecraftVersion: string,
  modLoader: PojlibModLoader = DEFAULT_POJLIB_MOD_LOADER
): string {
  return modLoader === DEFAULT_POJLIB_MOD_LOADER
    ? `QuestCraft ${minecraftVersion}`
    : `QuestCraft ${minecraftVersion} (${modLoader})`;
}

export function isPojlibBridgeAvailable(): boolean {
  return PojlibExpoModule.isPojlibBridgeAvailable();
}

export function getPojlibGitBranch(): string | null {
  return PojlibExpoModule.getPojlibGitBranch();
}

export function initializePojlib() {
  return PojlibExpoModule.initialize();
}

export function configurePojlib(config: PojlibConfig) {
  return PojlibExpoModule.configure(
    config.model ?? null,
    config.renderer ?? null,
    config.memoryValue ?? null,
    config.developerMods ?? null,
    config.ignoreInstanceName ?? null,
    config.customRAMValue ?? null,
    config.advancedDebugger ?? null
  );
}

export function getPojlibStatus() {
  return PojlibExpoModule.getStatus();
}

export function getPojlibSupportedVersions() {
  return PojlibExpoModule.getSupportedVersions();
}

function normalizeSupportedVersions(versions: string[] | null | undefined): string[] {
  if (!Array.isArray(versions)) {
    return [...FALLBACK_SUPPORTED_VERSIONS];
  }

  const normalized = versions
    .map((value) => value?.trim())
    .filter((value): value is string => Boolean(value));

  return normalized.length > 0 ? Array.from(new Set(normalized)) : [...FALLBACK_SUPPORTED_VERSIONS];
}

export function hasPojlibConnection() {
  return PojlibExpoModule.hasConnection();
}

export function listPojlibAccounts() {
  return PojlibExpoModule.listAccounts();
}

export function loginToPojlib(accountUUID?: string | null) {
  return PojlibExpoModule.login(accountUUID ?? null);
}

export function removePojlibAccount(uuid: string) {
  return PojlibExpoModule.removeAccount(uuid);
}

export function loadPojlibInstances() {
  return PojlibExpoModule.loadInstances();
}

export function getPojlibInstance(instanceName: string) {
  return PojlibExpoModule.getInstance(instanceName);
}

export function createPojlibInstance(options: CreatePojlibInstanceOptions) {
  return PojlibExpoModule.createInstance(
    options.instanceName,
    options.useDefaultMods,
    options.minecraftVersion,
    options.modLoader,
    options.imageURL ?? null
  );
}

export async function installDefaultPojlibInstance(options: InstallDefaultPojlibInstanceOptions) {
  const supportedVersions = normalizeSupportedVersions(await getPojlibSupportedVersions());

  if (!supportedVersions.includes(options.minecraftVersion)) {
    throw new Error(
      `Minecraft version '${options.minecraftVersion}' is not in Pojlib's supported versions: ${supportedVersions.join(', ')}`
    );
  }

  const modLoader = options.modLoader ?? DEFAULT_POJLIB_MOD_LOADER;
  const instanceName =
    options.instanceName?.trim() || getDefaultPojlibInstanceName(options.minecraftVersion, modLoader);

  return createPojlibInstance({
    instanceName,
    useDefaultMods: true,
    minecraftVersion: options.minecraftVersion,
    modLoader,
    imageURL: options.imageURL ?? null,
  });
}

export function createPojlibInstanceFromMrpack(options: CreatePojlibMrpackInstanceOptions) {
  return PojlibExpoModule.createInstanceFromMrpack(
    options.instanceName,
    options.imageURL ?? null,
    options.modLoader,
    options.mrpackFile
  );
}

export function deletePojlibInstance(instanceName: string) {
  return PojlibExpoModule.deleteInstance(instanceName);
}

export function addPojlibExtraProject(options: AddPojlibProjectOptions) {
  return PojlibExpoModule.addExtraProject(
    options.instanceName,
    options.name,
    options.fileName ?? null,
    options.version,
    options.url,
    options.type
  );
}

export function addPojlibModrinthVersion(options: AddPojlibModrinthVersionOptions) {
  return PojlibExpoModule.addModrinthVersionProject(
    options.instanceName,
    options.versionId,
    options.type ?? 'mod'
  );
}

export function importPojlibLocalProject(options: ImportLocalPojlibProjectOptions) {
  return PojlibExpoModule.importLocalProject(
    options.instanceName,
    options.name,
    options.sourcePath,
    options.fileName ?? null,
    options.type ?? 'mod'
  );
}

export function hasPojlibExtraProject(instanceName: string, name: string) {
  return PojlibExpoModule.hasExtraProject(instanceName, name);
}

export function removePojlibExtraProject(instanceName: string, name: string) {
  return PojlibExpoModule.removeExtraProject(instanceName, name);
}

export function prelaunchPojlibInstance(instanceName: string) {
  return PojlibExpoModule.prelaunch(instanceName);
}

export function launchPojlibInstance(instanceName: string, accountUUID?: string | null) {
  return PojlibExpoModule.launchInstance(instanceName, accountUUID ?? null);
}

export function getPojlibDownloadStatus() {
  return PojlibExpoModule.getDownloadStatus();
}

export function readPojlibLatestLog() {
  return PojlibExpoModule.readLatestLog();
}

export function readPojlibPreviousLog() {
  return PojlibExpoModule.readPreviousLog();
}
